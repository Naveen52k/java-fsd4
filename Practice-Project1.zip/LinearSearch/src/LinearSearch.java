public class LinearSearch {

    public static boolean linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return true; 
            }
        }
        return false; 
    }

    public static void main(String[] args) {
        int[] array = {2, 4, 6, 8, 10, 12, 14};
        int targetElementFound = 8;
        int targetElementNotFound = 5;

        boolean found = linearSearch(array, targetElementFound);
        boolean notFound = linearSearch(array, targetElementNotFound);

        if (found) {
            System.out.println("Element " + targetElementFound + " found in the array.");
        } else {
            System.out.println("Element " + targetElementFound + " not found in the array.");
        }

        if (notFound) {
            System.out.println("Element " + targetElementNotFound + " found in the array.");
        } else {
            System.out.println("Element " + targetElementNotFound + " not found in the array.");
        }
    }
}
